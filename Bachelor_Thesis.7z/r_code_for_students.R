# Required packages (to run this script you have to install some packages first)
# This is required only once:

install.packages("tidyverse")

# Load required packages ---------------------

library(tidyverse)

# crypto_returns contains return data for 30 assets downloaded from coinmarketcap. 
# Warning: These are returns only, you may consider substracting the 
#          risk-free before working with the data. 
# You only have to work with the crypto-currency you were assigned to.

# ff_returns is downloaded from the homepage of Kenneth French. It contains 
# daily factor returns from the Fama French 3 Factor model. To complete
# the basic empirical assignment you only need two variables: 
#      mkt.rf are daily market returns minus risk free rate
#      rf is the risk free rate, this may be important to adjust your crypto returns
#      smb and hml are the factor returns for the small-minus-big and the high-
#      minus-low factors. You can always extend your work and include these factors as well if you wish.

# crix_returns contains the daily Crypto-market index returns computed by Wolfang
# Härdle from HU Berlin. Use these returns as proxies for the crypto-market. 

# Read in data -------------------------------

crypto_returns <- readr::read_csv('crypto_returns.csv')
ff_returns <- readr::read_csv('ff3_returns.csv')
crix_returns <- readr::read_csv('crix_returns.csv')

# Adjust the data ---------------------------
# Note: This is the example for bitcoin, you may have to change the asset

r <- crypto_returns$bitcoin - ff_returns$rf
rm.equity <- ff_returns$mkt.rf
rm.crypto <- crix_returns$return - ff_returns$rf

df <- data.frame(date = crypto_returns$date,
                 bitcoin = r,
                 rm.equity,
                 rm.crypto) %>%
                 na.omit()

# Compute some summary statistics (average return, standard deviation and Sharpe ratio, all annualized)

summary_stats <- apply(df[,-1],2,function(x)c(Mean = 250*mean(x),
                                              Sd = sqrt(250)*sd(x), 
                                              Sharpe = sqrt(250)*mean(x)/sd(x)))

summary_stats

# Generate some plots

p0 <- ggplot(df%>%gather(asset, 
                         return, 
                         -date),
             aes(x=date, 
                 y=return,
                 color=asset))+
    geom_line()+
    theme_bw() 

print(p0)

# Store the figure if required 
ggsave('daily_returns.jpg', 
       p0, 
       device='jpeg', 
       width = 2*11, 
       height=8.5)

ggplot(df,aes(x = rm.equity, 
                    y = bitcoin)) + 
    geom_point(size=2) + 
    theme_bw() + 
    ggtitle('Daily returns: Bitcoin vs (equity) market') +
    geom_smooth(method='lm',formula=y~x, color='red')

ggplot(df,aes(x = rm.crypto, 
                    y = bitcoin)) + 
    geom_point(size=2) + 
    theme_bw() + 
    ggtitle('Daily returns: Bitcoin vs (crypto) market') +
    geom_smooth(method='lm',formula=y~x, color='red')

# If you want to go multi-dimensional (optional)

devtools::install_version("plotly", 
                          version = "4.5.6", 
                          repos = "http://cran.us.r-project.org")
library(plotly)

plot_ly(df, 
             x = ~rm.equity, 
             y = ~rm.crypto, 
             z = ~bitcoin,
             colors='black') %>%
    add_markers() %>%
    layout(scene = list(xaxis = list(title = 'Equity'),
                        yaxis = list(title = 'Crypto market'),
                        zaxis = list(title = 'Bitcoin return')))
